const reportWebVitals = () => {
  // Performance reporting disabled
};

export default reportWebVitals;