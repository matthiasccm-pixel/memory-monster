import React, { useState, useEffect } from 'react';
import { Zap, Chrome, MessageSquare, Headphones, Lock, Crown, RotateCcw, CheckCircle, Shield, Sparkles, Activity, Users, Settings, ChevronRight, Package } from 'lucide-react';
import { useFeatureGate } from '../../core/licensing/useFeatureGate.js';
import { containerStyle } from '../../styles/commonStyles.js';
import AppLogo from '../shared/AppLogo.jsx';
import SpeedDial from './SpeedDial.jsx';
import Firefoxlogo from '../shared/Firefoxlogo.jsx';
import ActivatePlanModal from '../modals/ActivatePlanModal.jsx';
import CommunityStats from '../shared/CommunityStats.jsx';

const SpeedTracker = ({ 
  currentView, 
  setCurrentView,
  issues,
  setIssues,
  fixingStates,
  setFixingStates,
  handleFix,
  animatingMemory,
  getSeverityStyle
}) => {
  // Local state for this component
  const [currentSpeed, setCurrentSpeed] = useState(24);
  const [isScanning, setIsScanning] = useState(false);
  const [hasScanned, setHasScanned] = useState(false);
  const [optimizationProgress, setOptimizationProgress] = useState(0);
  const [progressText, setProgressText] = useState('');
  const [activeOptimization, setActiveOptimization] = useState(null);
  const [minimizedIssues, setMinimizedIssues] = useState({});
  const [showVictoryCard, setShowVictoryCard] = useState(false);
  const [showActivationModal, setShowActivationModal] = useState(false);

  // Community stats state - simplified
  const [currentCommunityIndex, setCurrentCommunityIndex] = useState(0);

  // Feature gating
  const { hasFeature, getRemainingScans, decrementScans, openUpgradeModal, isPro, isFree } = useFeatureGate();

  // Calculate current speed based on fixed issues
  useEffect(() => {
    const totalIssues = issues.length;
    const fixedIssues = issues.filter(issue => issue.fixed).length;
    if (totalIssues > 0) {
      const speedIncrease = Math.floor((fixedIssues / totalIssues) * 65); // Up to 65% increase
      setCurrentSpeed(24 + speedIncrease);
    }
  }, [issues]);

  // Check if all issues are fixed and minimized
  useEffect(() => {
    if (hasScanned && issues.length > 0) {
      const allFixed = issues.every(issue => issue.fixed);
      const allMinimized = issues.every(issue => minimizedIssues[issue.id]);
      
      if (allFixed && allMinimized && !showVictoryCard) {
        // Trigger victory animation
        setTimeout(() => {
          setShowVictoryCard(true);
        }, 1000);
      }
    }
  }, [issues, minimizedIssues, hasScanned, showVictoryCard]);

  // Handle scan action
  const handleScan = () => {
    if (isFree && getRemainingScans() <= 0) {
      setShowActivationModal(true);
      return;
    }

    setIsScanning(true);
    setHasScanned(false);
    setShowVictoryCard(false);
    setMinimizedIssues({});

    // Decrement scans for free users
    if (isFree) {
      decrementScans();
    }

    setTimeout(() => {
      setIsScanning(false);
      setHasScanned(true);
    }, 3000);
  };

  // Handle optimization with progress tracking
  const handleOptimizeWithProgress = async (issueId) => {
    const issue = issues.find(i => i.id === issueId);
    setActiveOptimization(issueId);
    setOptimizationProgress(0);

    // Progress simulation
    const progressSteps = [
      { progress: 20, text: 'Analyzing...', delay: 800 },
      { progress: 60, text: 'Optimizing...', delay: 1500 },
      { progress: 100, text: 'Complete!', delay: 1200 }
    ];

    for (const step of progressSteps) {
      await new Promise(resolve => {
        setTimeout(() => {
          setOptimizationProgress(step.progress);
          setProgressText(step.text);
          resolve();
        }, step.delay);
      });
    }

    // Call the actual fix handler
    handleFix(issueId);
    
    // Reset progress and minimize the card
    setTimeout(() => {
      setActiveOptimization(null);
      setOptimizationProgress(0);
      setProgressText('');
      setMinimizedIssues(prev => ({ ...prev, [issueId]: true }));
    }, 1000);
  };

  // Handle optimize all
  const handleOptimizeAll = () => {
    setShowActivationModal(true);
  };

  // Handle activation modal actions
  const handleActivateNow = () => {
    setShowActivationModal(false);
    window.open('https://memorymonster.co/join', '_blank');
  };

  const handleBuyPlan = () => {
    setShowActivationModal(false);
    window.open('https://memorymonster.co/join', '_blank');
  };

  const handleSkipActivation = () => {
    setShowActivationModal(false);
  };

  // Handle unlock full version
  const handleUnlockFullVersion = () => {
    window.open('https://memorymonster.co/join', '_blank');
  };

  // Get scan button text and style
  const getScanButtonConfig = () => {
    const remaining = getRemainingScans();
    
    if (isPro) {
      return {
        text: 'Auto-Monitoring Active',
        style: 'bg-gradient-to-r from-green-500 to-emerald-600',
        disabled: false,
        icon: <Crown className="w-5 h-5" />
      };
    }
    
    if (remaining > 0) {
      const scanTexts = {
        3: 'Scan for Issues (3 scans left)',
        2: 'Scan Again (2 scans left)', 
        1: 'Final Scan (1 scan left)'
      };
      return {
        text: scanTexts[remaining],
        style: remaining === 1 ? 'bg-gradient-to-r from-orange-500 to-red-500' : 'bg-gradient-to-r from-blue-500 to-purple-600',
        disabled: false,
        icon: <Zap className="w-5 h-5" />
      };
    }
    
    return {
      text: 'No Scans Left - Upgrade to Pro',
      style: 'bg-gray-400 cursor-not-allowed',
      disabled: true,
      icon: <Lock className="w-5 h-5" />
    };
  };

  const scanConfig = getScanButtonConfig();

  // Calculate scan results summary
  const getScanSummary = () => {
    if (!hasScanned || issues.length === 0) return '';
    
    const unfixedIssues = issues.filter(issue => !issue.fixed);
    const totalSpeedGain = issues.reduce((sum, issue) => sum + (issue.impact || 0), 0);
    
    if (unfixedIssues.length === 0) {
      return `🎉 All Speed Drains Fixed! +${totalSpeedGain}% Performance Boost`;
    }
    
    return `Found ${unfixedIssues.length} Speed Drain${unfixedIssues.length > 1 ? 's' : ''} • Your Mac Could Be ${totalSpeedGain}% Faster`;
  };

  // Sidebar styles - UPDATED WITH HOVER STATES
  const sidebarStyle = {
    background: `linear-gradient(180deg, rgba(255, 255, 255, 0.15) 0%, rgba(255, 255, 255, 0.10) 50%, rgba(255, 255, 255, 0.05) 100%)`,
    backdropFilter: 'blur(24px) saturate(180%)',
    borderRight: '1px solid rgba(255, 255, 255, 0.2)',
    padding: '40px 32px',
    display: 'flex',
    flexDirection: 'column',
    gap: '12px',
    boxShadow: '0 0 40px rgba(0, 0, 0, 0.3) inset'
  };

  const sidebarItemStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: '16px',
    padding: '16px 20px',
    borderRadius: '16px',
    color: 'rgba(255, 255, 255, 0.8)',
    cursor: 'pointer',
    transition: 'all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)',
    fontSize: '15px',
    fontWeight: '600',
    position: 'relative',
    overflow: 'hidden'
  };

  const hoverSidebarItemStyle = {
    ...sidebarItemStyle,
    background: `linear-gradient(135deg, rgba(114, 9, 183, 0.2) 0%, rgba(83, 52, 131, 0.15) 100%)`,
    color: 'rgba(255, 255, 255, 0.95)',
    boxShadow: `0 4px 16px rgba(114, 9, 183, 0.2)`
  };

  const activeSidebarItemStyle = {
    ...sidebarItemStyle,
    background: `linear-gradient(135deg, rgba(114, 9, 183, 0.4) 0%, rgba(83, 52, 131, 0.3) 100%)`,
    color: 'white',
    boxShadow: `0 8px 32px rgba(114, 9, 183, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.2) inset`
  };

  return (
    <div style={containerStyle}>
      {/* Activation Modal */}
      {showActivationModal && (
        <ActivatePlanModal 
          onSkip={handleSkipActivation}
          onActivateNow={handleActivateNow}
          onBuyPlan={handleBuyPlan}
        />
      )}

      {/* Main layout container */}
      <div style={{
        height: '100vh',
        display: 'grid',
        gridTemplateColumns: '320px 1fr 400px', // Left nav, center content, right panel
        overflow: 'hidden',
        position: 'relative'
      }}>
        
        {/* Left Sidebar - UPDATED NAVIGATION */}
        <div style={sidebarStyle}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '40px', padding: '0 4px' }}>
            <div style={{ width: '48px', height: '48px', background: `linear-gradient(135deg, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0.1) 100%)`, borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', backdropFilter: 'blur(10px)', border: '1px solid rgba(255, 255, 255, 0.15)' }}>
              <Firefoxlogo size={32} />
            </div>
            <div>
              <h2 style={{ color: 'white', fontSize: '18px', fontWeight: '800', margin: '0 0 2px 0' }}>Memory Monster</h2>
              <p style={{ color: 'rgba(255, 255, 255, 0.7)', fontSize: '12px', margin: '0', fontWeight: '500' }}>Speed Tracker</p>
            </div>
          </div>

          {/* Updated Navigation - Clean 3-item structure with hover states */}
          <div 
            style={currentView === 'speedTracker' ? activeSidebarItemStyle : sidebarItemStyle} 
            onClick={() => setCurrentView('speedTracker')}
            onMouseEnter={(e) => {
              if (currentView !== 'speedTracker') {
                Object.assign(e.target.style, hoverSidebarItemStyle);
              }
            }}
            onMouseLeave={(e) => {
              if (currentView !== 'speedTracker') {
                Object.assign(e.target.style, sidebarItemStyle);
              }
            }}
          >
            <Activity size={20} />
            <span>🚀 Speed Tracker</span>
          </div>
          <div 
            style={currentView === 'apps' ? activeSidebarItemStyle : sidebarItemStyle} 
            onClick={() => setCurrentView('apps')}
            onMouseEnter={(e) => {
              if (currentView !== 'apps') {
                Object.assign(e.target.style, hoverSidebarItemStyle);
              }
            }}
            onMouseLeave={(e) => {
              if (currentView !== 'apps') {
                Object.assign(e.target.style, sidebarItemStyle);
              }
            }}
          >
            <Package size={20} />
            <span>Apps</span>
            {/* Pro badge for Apps */}
            <div style={{
              background: 'linear-gradient(135deg, #7209b7 0%, #533483 100%)',
              color: 'white',
              fontSize: '10px',
              fontWeight: '700',
              padding: '2px 6px',
              borderRadius: '6px',
              marginLeft: 'auto'
            }}>
              PRO
            </div>
          </div>
          <div 
            style={currentView === 'settings' ? activeSidebarItemStyle : sidebarItemStyle} 
            onClick={() => setCurrentView('settings')}
            onMouseEnter={(e) => {
              if (currentView !== 'settings') {
                Object.assign(e.target.style, hoverSidebarItemStyle);
              }
            }}
            onMouseLeave={(e) => {
              if (currentView !== 'settings') {
                Object.assign(e.target.style, sidebarItemStyle);
              }
            }}
          >
            <Settings size={20} />
            <span>Settings</span>
          </div>

          <div style={{ flex: 1 }}></div>

          {/* Community Stats - Only show for free users - Fixed positioning */}
          {isFree && (
            <div style={{ marginTop: 'auto', paddingTop: '20px' }}>
              <CommunityStats onUnlockClick={handleUnlockFullVersion} />
            </div>
          )}
        </div>

        {/* Main Content Area - Speed Dial Section */}
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '48px',
          position: 'relative'
        }}>
          {/* Your existing SpeedDial component */}
          <div style={{ position: 'relative', marginBottom: '48px' }}>
            <SpeedDial 
              currentSpeed={currentSpeed}
              onScanComplete={() => {
                console.log('Speed assessment complete');
              }}
              size="large"
            />
          </div>

          {/* Scan Button - Styled to match your theme */}
          <button
            onClick={!scanConfig.disabled ? handleScan : () => setShowActivationModal(true)}
            disabled={isScanning}
            style={{
              padding: '20px 40px',
              borderRadius: '20px',
              border: 'none',
              fontSize: '18px',
              fontWeight: '700',
              cursor: scanConfig.disabled ? 'not-allowed' : 'pointer',
              transition: 'all 0.3s ease',
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              opacity: isScanning ? 0.7 : 1,
              background: scanConfig.disabled 
                ? 'rgba(255, 255, 255, 0.1)' 
                : `linear-gradient(135deg, #7209b7 0%, #533483 100%)`,
              color: 'white',
              boxShadow: '0 16px 40px rgba(114, 9, 183, 0.4)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.2)'
            }}
            onMouseEnter={(e) => {
              if (!scanConfig.disabled && !isScanning) {
                e.target.style.transform = 'translateY(-2px) scale(1.05)';
                e.target.style.boxShadow = '0 20px 48px rgba(114, 9, 183, 0.5)';
              }
            }}
            onMouseLeave={(e) => {
              if (!scanConfig.disabled && !isScanning) {
                e.target.style.transform = 'translateY(0) scale(1)';
                e.target.style.boxShadow = '0 16px 40px rgba(114, 9, 183, 0.4)';
              }
            }}
          >
            {isScanning ? (
              <>
                <div style={{
                  width: '24px',
                  height: '24px',
                  border: '3px solid rgba(255, 255, 255, 0.3)',
                  borderTop: '3px solid white',
                  borderRadius: '50%',
                  animation: 'spin 1s linear infinite'
                }} />
                Scanning...
              </>
            ) : (
              <>
                {scanConfig.icon}
                {scanConfig.text}
              </>
            )}
          </button>
        </div>

        {/* Right Panel - Problem List with glassmorphism */}
        <div style={{
          background: `linear-gradient(135deg, rgba(255, 255, 255, 0.25) 0%, rgba(255, 255, 255, 0.15) 100%)`,
          backdropFilter: 'blur(32px) saturate(180%)',
          borderLeft: '1px solid rgba(255, 255, 255, 0.2)',
          padding: '24px',
          overflowY: 'auto',
          maxHeight: '100vh',
          boxShadow: '0 0 40px rgba(0, 0, 0, 0.1) inset',
          display: 'flex',
          flexDirection: 'column'
        }}>
          
          {/* Header */}
          <div style={{
            marginBottom: '20px'
          }}>
            <div style={{
              fontSize: '20px', // Bigger title
              fontWeight: '700',
              color: 'white',
              textShadow: '0 2px 8px rgba(0, 0, 0, 0.3)',
              marginBottom: '4px'
            }}>
              🎯 Speed Problems
            </div>
            
            {hasScanned && (
              <div style={{
                fontSize: '12px',
                color: 'rgba(255, 255, 255, 0.8)',
                fontWeight: '500',
                marginBottom: '16px'
              }}>
                {getScanSummary()}
              </div>
            )}

            {/* Progress Bar under subtitle */}
            {activeOptimization && (
              <div style={{
                marginBottom: '16px',
                textAlign: 'left'
              }}>
                <div style={{
                  width: '100%',
                  height: '16px',
                  background: 'rgba(255, 255, 255, 0.2)',
                  borderRadius: '8px',
                  overflow: 'hidden',
                  marginBottom: '8px',
                  backdropFilter: 'blur(10px)',
                  border: '1px solid rgba(255, 255, 255, 0.3)'
                }}>
                  <div style={{
                    width: `${optimizationProgress}%`,
                    height: '100%',
                    background: 'linear-gradient(90deg, #10b981, #3b82f6, #8b5cf6)',
                    borderRadius: '8px',
                    transition: 'width 0.5s ease',
                    boxShadow: '0 0 20px rgba(16, 185, 129, 0.5)'
                  }} />
                </div>
                <div style={{
                  color: 'white',
                  fontSize: '12px',
                  fontWeight: '700',
                  textShadow: '0 2px 8px rgba(0, 0, 0, 0.3)'
                }}>
                  {progressText}
                </div>
              </div>
            )}
          </div>

          {/* Content Area */}
          <div style={{ flex: 1 }}>
            {/* No scan state */}
            {!hasScanned && !isScanning && (
              <div style={{
                textAlign: 'center',
                padding: '48px 24px',
                color: 'rgba(255, 255, 255, 0.8)'
              }}>
                <div style={{
                  fontSize: '48px',
                  marginBottom: '16px'
                }}>
                  🔍
                </div>
                <div style={{
                  fontSize: '16px',
                  fontWeight: '600',
                  marginBottom: '8px',
                  color: 'white'
                }}>
                  Click 'Scan for Issues'
                </div>
                <div style={{
                  fontSize: '14px',
                  lineHeight: '1.5'
                }}>
                  to find apps slowing down your Mac
                </div>
              </div>
            )}

            {/* Scanning state */}
            {isScanning && (
              <div style={{
                textAlign: 'center',
                padding: '48px 24px',
                color: 'rgba(255, 255, 255, 0.8)'
              }}>
                <div style={{
                  fontSize: '48px',
                  marginBottom: '16px',
                  animation: 'pulse 2s infinite'
                }}>
                  ⚡
                </div>
                <div style={{
                  fontSize: '16px',
                  fontWeight: '600',
                  marginBottom: '8px',
                  color: 'white'
                }}>
                  Scanning Your Mac...
                </div>
                <div style={{
                  fontSize: '14px',
                  lineHeight: '1.5'
                }}>
                  Finding performance bottlenecks
                </div>
              </div>
            )}

            {/* Victory Card - Auto height */}
            {showVictoryCard && (
              <div style={{
                background: `linear-gradient(135deg, rgba(16, 185, 129, 0.9) 0%, rgba(59, 130, 246, 0.9) 100%)`,
                backdropFilter: 'blur(20px)',
                borderRadius: '20px',
                padding: '32px 24px',
                color: 'white',
                border: '1px solid rgba(255, 255, 255, 0.3)',
                boxShadow: '0 16px 48px rgba(16, 185, 129, 0.3)',
                animation: 'slideIn 0.5s ease-out',
                position: 'relative'
              }}>
                {/* Pro Banner */}
                <div style={{
                  position: 'absolute',
                  top: '16px',
                  right: '16px',
                  background: 'rgba(255, 255, 255, 0.2)',
                  borderRadius: '12px',
                  padding: '8px 12px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  border: '1px solid rgba(255, 255, 255, 0.3)'
                }}>
                  <Lock className="w-4 h-4" />
                  <span style={{ fontSize: '12px', fontWeight: '600' }}>✨ PRO ✨</span>
                </div>

                {/* Top Half - Celebration */}
                <div style={{ textAlign: 'center', marginBottom: '24px' }}>
                  <div style={{ fontSize: '48px', marginBottom: '12px' }}>🎉</div>
                  <div style={{ fontSize: '18px', fontWeight: '700', marginBottom: '8px' }}>
                    Amazing! All Speed Drains Fixed!
                  </div>
                  <div style={{ fontSize: '14px', opacity: 0.9, marginBottom: '12px' }}>
                    Your Mac is now {currentSpeed}% faster and running at peak performance
                  </div>
                  {isFree && (
                    <div style={{ fontSize: '13px', opacity: 0.8 }}>
                      {getRemainingScans()} scans remaining 😢
                    </div>
                  )}
                </div>

                {/* Bottom Half - Upsell */}
                {isFree && (
                  <div>
                    <div style={{
                      background: 'rgba(255, 255, 255, 0.1)',
                      borderRadius: '12px',
                      padding: '20px',
                      marginBottom: '20px'
                    }}>
                      <div style={{ 
                        fontSize: '14px', 
                        fontWeight: '600', 
                        marginBottom: '12px',
                        textAlign: 'left'
                      }}>
                        Join 1M users worldwide using Memory Monster daily
                      </div>
                      <div style={{ fontSize: '13px', lineHeight: '1.6', marginBottom: '16px', textAlign: 'left' }}>
                        ✅ Unlimited Speed Scans<br/>
                        ✅ Real-time Performance Tracking<br/>
                        ✅ Supercharged with AI<br/>
                        ✅ Unlock 250+ Apps<br/>
                        ✅ All New Features & Tools
                      </div>
                      <div style={{ 
                        background: 'rgba(255, 255, 255, 0.15)',
                        borderRadius: '20px',
                        padding: '8px 16px',
                        fontSize: '12px', 
                        fontWeight: '600', 
                        textAlign: 'center',
                        border: '1px solid rgba(255, 255, 255, 0.2)',
                        display: 'inline-block',
                        width: '100%'
                      }}>
                        All for the price of a coffee ☕
                      </div>
                    </div>

                    <button
                      onClick={() => window.open('https://memorymonster.co/join', '_blank')}
                      style={{
                        width: '100%',
                        padding: '14px 24px',
                        background: 'rgba(255, 255, 255, 0.2)',
                        border: '1px solid rgba(255, 255, 255, 0.3)',
                        borderRadius: '12px',
                        color: 'white',
                        fontSize: '16px',
                        fontWeight: '700',
                        cursor: 'pointer',
                        transition: 'all 0.2s ease',
                        backdropFilter: 'blur(10px)'
                      }}
                      onMouseEnter={(e) => {
                        e.target.style.background = 'rgba(255, 255, 255, 0.3)';
                        e.target.style.transform = 'translateY(-1px)';
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.background = 'rgba(255, 255, 255, 0.2)';
                        e.target.style.transform = 'translateY(0)';
                      }}
                    >
                      🚀 Unlock Pro Today
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Issues list */}
            {hasScanned && !showVictoryCard && issues.map((issue) => (
              <div 
                key={issue.id} 
                style={{
                  background: `linear-gradient(135deg, rgba(255, 255, 255, 0.35) 0%, rgba(255, 255, 255, 0.25) 100%)`, // Less opaque
                  backdropFilter: 'blur(20px)',
                  borderRadius: '16px',
                  padding: minimizedIssues[issue.id] ? '12px 20px' : '20px',
                  marginBottom: '12px',
                  border: '1px solid rgba(255, 255, 255, 0.2)',
                  boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
                  transition: 'all 0.3s ease',
                  height: minimizedIssues[issue.id] ? '60px' : 'auto',
                  overflow: 'hidden'
                }}
              >
                {minimizedIssues[issue.id] ? (
                  // Minimized state
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    height: '100%'
                  }}>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px'
                    }}>
                      <AppLogo app={issue.app} size={24} />
                      <div style={{
                        fontSize: '14px',
                        fontWeight: '600',
                        color: '#1f2937' // Better contrast
                      }}>
                        {issue.app} Optimized
                      </div>
                    </div>
                    <CheckCircle className="w-5 h-5" style={{ color: '#10b981' }} />
                  </div>
                ) : (
                  // Full state
                  <>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      marginBottom: '12px'
                    }}>
                      <AppLogo app={issue.app} size={28} />
                      <div style={{
                        marginLeft: '12px',
                        flex: 1
                      }}>
                        <div style={{
                          fontSize: '15px',
                          fontWeight: '700',
                          color: '#1f2937' // Better contrast
                        }}>
                          {issue.app}
                        </div>
                        <div style={{
                          fontSize: '13px',
                          color: '#374151', // Better contrast
                          fontWeight: '600'
                        }}>
                          {issue.severity} • +{issue.impact}% speed impact
                        </div>
                      </div>
                    </div>
                    
                    <div style={{
                      fontSize: '13px',
                      color: '#6b7280',
                      marginBottom: '16px',
                      lineHeight: '1.4'
                    }}>
                      {issue.storage}{issue.storageUnit} memory drain
                    </div>

                    {/* Optimize button */}
                    {!issue.fixed ? (
                      <button
                        onClick={() => handleOptimizeWithProgress(issue.id)}
                        disabled={activeOptimization === issue.id || (isFree && getRemainingScans() <= 0)}
                        style={{
                          width: '100%',
                          padding: '12px 20px',
                          borderRadius: '12px',
                          border: 'none',
                          fontSize: '14px',
                          fontWeight: '600',
                          cursor: activeOptimization === issue.id || (isFree && getRemainingScans() <= 0) ? 'not-allowed' : 'pointer',
                          background: activeOptimization === issue.id 
                            ? 'rgba(156, 163, 175, 0.5)' 
                            : (isFree && getRemainingScans() <= 0)
                              ? 'rgba(229, 231, 235, 0.8)'
                              : 'linear-gradient(135deg, #7209b7, #533483)', // Purple colorway
                          color: (isFree && getRemainingScans() <= 0) ? '#9ca3af' : 'white',
                          transition: 'all 0.2s ease',
                          boxShadow: activeOptimization !== issue.id && !(isFree && getRemainingScans() <= 0) ? '0 4px 16px rgba(114, 9, 183, 0.3)' : 'none'
                        }}
                      >
                        {activeOptimization === issue.id ? (
                          'Optimizing...'
                        ) : (isFree && getRemainingScans() <= 0) ? (
                          'Upgrade to Pro'
                        ) : (
                          `Speed Up ${issue.app}`
                        )}
                      </button>
                    ) : (
                      <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        padding: '12px 20px',
                        background: `linear-gradient(135deg, rgba(16, 185, 129, 0.2) 0%, rgba(52, 211, 153, 0.2) 100%)`,
                        borderRadius: '12px',
                        color: '#10b981',
                        fontSize: '14px',
                        fontWeight: '600',
                        border: '1px solid rgba(16, 185, 129, 0.3)'
                      }}>
                        <CheckCircle className="w-4 h-4" style={{ marginRight: '8px' }} />
                        Optimized • +{issue.impact}% speed boost
                      </div>
                    )}
                  </>
                )}
              </div>
            ))}
          </div>

          {/* Optimize All Button at Bottom */}
          {hasScanned && !showVictoryCard && issues.some(issue => !issue.fixed) && (
            <button
              onClick={handleOptimizeAll}
              style={{
                width: '100%',
                padding: '16px 24px',
                borderRadius: '16px',
                border: 'none',
                fontSize: '16px',
                fontWeight: '700',
                cursor: 'pointer',
                background: 'linear-gradient(135deg, #7209b7, #533483)',
                color: 'white',
                transition: 'all 0.2s ease',
                boxShadow: '0 8px 24px rgba(114, 9, 183, 0.4)',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                marginTop: '16px'
              }}
              onMouseEnter={(e) => {
                e.target.style.transform = 'translateY(-2px)';
                e.target.style.boxShadow = '0 12px 32px rgba(114, 9, 183, 0.5)';
              }}
              onMouseLeave={(e) => {
                e.target.style.transform = 'translateY(0)';
                e.target.style.boxShadow = '0 8px 24px rgba(114, 9, 183, 0.4)';
              }}
            >
              🚀 Optimize All
            </button>
          )}
        </div>
      </div>

      {/* Add CSS animations */}
      <style>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
        @keyframes slideIn {
          0% { opacity: 0; transform: translateY(20px) scale(0.95); }
          100% { opacity: 1; transform: translateY(0) scale(1); }
        }
      `}</style>
    </div>
  );
};

export default SpeedTracker;