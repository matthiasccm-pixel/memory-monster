import React from 'react';
import { Package, Lock, Crown, Activity, Settings } from 'lucide-react';
import { useFeatureGate } from '../../core/licensing/useFeatureGate.js';
import Firefoxlogo from '../shared/Firefoxlogo.jsx';
import CommunityStats from '../shared/CommunityStats.jsx';

const AppsView = ({ currentView, setCurrentView }) => {
  const { isFree } = useFeatureGate();

  // Handle unlock full version
  const handleUnlockFullVersion = () => {
    window.open('https://memorymonster.co/join', '_blank');
  };

  // Styles
  const mainContentStyle = {
    height: '100vh',
    display: 'grid',
    gridTemplateColumns: '320px 1fr',
    overflow: 'hidden',
    position: 'relative'
  };

  const sidebarStyle = {
    background: `linear-gradient(180deg, rgba(255, 255, 255, 0.15) 0%, rgba(255, 255, 255, 0.10) 50%, rgba(255, 255, 255, 0.05) 100%)`,
    backdropFilter: 'blur(24px) saturate(180%)',
    borderRight: '1px solid rgba(255, 255, 255, 0.2)',
    padding: '40px 32px',
    display: 'flex',
    flexDirection: 'column',
    gap: '12px',
    boxShadow: '0 0 40px rgba(0, 0, 0, 0.3) inset'
  };

  const sidebarItemStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: '16px',
    padding: '16px 20px',
    borderRadius: '16px',
    color: 'rgba(255, 255, 255, 0.8)',
    cursor: 'pointer',
    transition: 'all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)',
    fontSize: '15px',
    fontWeight: '600',
    position: 'relative',
    overflow: 'hidden'
  };

  const hoverSidebarItemStyle = {
    ...sidebarItemStyle,
    background: `linear-gradient(135deg, rgba(114, 9, 183, 0.2) 0%, rgba(83, 52, 131, 0.15) 100%)`,
    color: 'rgba(255, 255, 255, 0.95)',
    boxShadow: `0 4px 16px rgba(114, 9, 183, 0.2)`
  };

  const activeSidebarItemStyle = {
    ...sidebarItemStyle,
    background: `linear-gradient(135deg, rgba(114, 9, 183, 0.4) 0%, rgba(83, 52, 131, 0.3) 100%)`,
    color: 'white',
    boxShadow: `0 8px 32px rgba(114, 9, 183, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.2) inset`
  };

  return (
    <div style={mainContentStyle}>
      {/* Sidebar */}
      <div style={sidebarStyle}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '40px', padding: '0 4px' }}>
          <div style={{ width: '48px', height: '48px', background: `linear-gradient(135deg, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0.1) 100%)`, borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', backdropFilter: 'blur(10px)', border: '1px solid rgba(255, 255, 255, 0.15)' }}>
            <Firefoxlogo size={32} />
          </div>
          <div>
            <h2 style={{ color: 'white', fontSize: '18px', fontWeight: '800', margin: '0 0 2px 0' }}>Memory Monster</h2>
            <p style={{ color: 'rgba(255, 255, 255, 0.7)', fontSize: '12px', margin: '0', fontWeight: '500' }}>App Library</p>
          </div>
        </div>
        
        {/* Navigation with hover states */}
        <div 
          style={currentView === 'speedTracker' ? activeSidebarItemStyle : sidebarItemStyle} 
          onClick={() => setCurrentView('speedTracker')}
          onMouseEnter={(e) => {
            if (currentView !== 'speedTracker') {
              Object.assign(e.target.style, hoverSidebarItemStyle);
            }
          }}
          onMouseLeave={(e) => {
            if (currentView !== 'speedTracker') {
              Object.assign(e.target.style, sidebarItemStyle);
            }
          }}
        >
          <Activity size={20} />
          <span>🚀 Speed Tracker</span>
        </div>
        <div 
          style={currentView === 'apps' ? activeSidebarItemStyle : sidebarItemStyle} 
          onClick={() => setCurrentView('apps')}
          onMouseEnter={(e) => {
            if (currentView !== 'apps') {
              Object.assign(e.target.style, hoverSidebarItemStyle);
            }
          }}
          onMouseLeave={(e) => {
            if (currentView !== 'apps') {
              Object.assign(e.target.style, sidebarItemStyle);
            }
          }}
        >
          <Package size={20} />
          <span>Apps</span>
          {/* Pro badge for Apps */}
          <div style={{
            background: 'linear-gradient(135deg, #7209b7 0%, #533483 100%)',
            color: 'white',
            fontSize: '10px',
            fontWeight: '700',
            padding: '2px 6px',
            borderRadius: '6px',
            marginLeft: 'auto'
          }}>
            PRO
          </div>
        </div>
        <div 
          style={currentView === 'settings' ? activeSidebarItemStyle : sidebarItemStyle} 
          onClick={() => setCurrentView('settings')}
          onMouseEnter={(e) => {
            if (currentView !== 'settings') {
              Object.assign(e.target.style, hoverSidebarItemStyle);
            }
          }}
          onMouseLeave={(e) => {
            if (currentView !== 'settings') {
              Object.assign(e.target.style, sidebarItemStyle);
            }
          }}
        >
          <Settings size={20} />
          <span>Settings</span>
        </div>
        
        <div style={{ flex: 1 }}></div>
        
        {/* Community Stats - Only show for free users */}
        {isFree && (
          <div style={{ marginTop: 'auto', paddingTop: '20px' }}>
            <CommunityStats onUnlockClick={handleUnlockFullVersion} />
          </div>
        )}
      </div>

      {/* Main Content - Pro Feature Placeholder */}
      <div style={{ 
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '40px',
        height: '100vh'
      }}>
        <div style={{
          background: `linear-gradient(135deg, #7209b7 0%, #533483 50%, #16213e 100%)`,
          borderRadius: '24px',
          padding: '48px 40px',
          textAlign: 'center',
          color: 'white',
          maxWidth: '500px',
          width: '100%',
          position: 'relative',
          overflow: 'hidden',
          boxShadow: '0 24px 48px rgba(114, 9, 183, 0.3)',
          border: '1px solid rgba(255, 255, 255, 0.1)'
        }}>
          {/* Animated background glow */}
          <div style={{
            position: 'absolute',
            top: '-50%',
            left: '-50%',
            width: '200%',
            height: '200%',
            background: `conic-gradient(from 0deg, rgba(114, 9, 183, 0.3), rgba(83, 52, 131, 0.2), rgba(15, 52, 96, 0.1), rgba(114, 9, 183, 0.3))`,
            animation: 'smoothRotate 8s linear infinite',
            filter: 'blur(20px)',
            opacity: 0.6
          }} />

          <div style={{ position: 'relative', zIndex: 2 }}>
            {/* Icon */}
            <div style={{
              width: '80px',
              height: '80px',
              background: 'rgba(255, 255, 255, 0.15)',
              borderRadius: '24px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 24px auto',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.2)'
            }}>
              <Package size={40} color="white" />
            </div>

            {/* Title */}
            <h1 style={{
              fontSize: '32px',
              fontWeight: '800',
              margin: '0 0 16px 0',
              letterSpacing: '-1px'
            }}>
              App Library
            </h1>

            {/* Description */}
            <p style={{
              fontSize: '18px',
              margin: '0 0 32px 0',
              fontWeight: '500',
              opacity: 0.9,
              lineHeight: '1.5'
            }}>
              Optimize 250+ specific apps with AI-powered recommendations and custom rules.
            </p>

            {/* Features list */}
            <div style={{
              background: 'rgba(255, 255, 255, 0.1)',
              borderRadius: '16px',
              padding: '24px',
              margin: '0 0 32px 0',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.15)',
              textAlign: 'left'
            }}>
              <div style={{
                fontSize: '16px',
                fontWeight: '600',
                marginBottom: '16px',
                textAlign: 'center'
              }}>
                Pro Features:
              </div>
              <div style={{
                fontSize: '15px',
                display: 'flex',
                flexDirection: 'column',
                gap: '8px'
              }}>
                <div>📱 250+ supported apps including Adobe Creative Suite</div>
                <div>🤖 AI-powered optimization recommendations</div>
                <div>⚙️ Custom rules and automation</div>
                <div>📊 App-specific performance analytics</div>
                <div>🔄 Real-time app monitoring</div>
              </div>
            </div>

            {/* CTA Button */}
            <button 
              onClick={handleUnlockFullVersion}
              style={{
                width: '100%',
                padding: '18px 32px',
                background: 'rgba(255, 255, 255, 0.15)',
                color: 'white',
                border: '1px solid rgba(255, 255, 255, 0.3)',
                borderRadius: '16px',
                fontSize: '18px',
                fontWeight: '700',
                cursor: 'pointer',
                backdropFilter: 'blur(10px)',
                transition: 'all 0.3s ease',
                boxShadow: '0 8px 24px rgba(0, 0, 0, 0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '12px'
              }}
              onMouseEnter={(e) => {
                e.target.style.background = 'rgba(255, 255, 255, 0.25)';
                e.target.style.transform = 'translateY(-2px)';
                e.target.style.boxShadow = '0 12px 32px rgba(0, 0, 0, 0.3)';
              }}
              onMouseLeave={(e) => {
                e.target.style.background = 'rgba(255, 255, 255, 0.15)';
                e.target.style.transform = 'translateY(0)';
                e.target.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.2)';
              }}
            >
              <Crown size={24} />
              Upgrade to Pro
            </button>
          </div>
        </div>
      </div>

      {/* CSS Animations */}
      <style>{`
        @keyframes smoothRotate {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default AppsView;