/**
 * FeatureGate.js - Controls access to Free vs Pro features
 * This is the brain that decides what users can access
 */

class FeatureGate {
  constructor() {
    // For now, we'll simulate different license states
    // Later this will connect to real license validation
    this.licenseStatus = this.getLicenseStatus();
    this.initializeScanCount();
  }

  getLicenseStatus() {
    // Check what's stored locally (for now)
    // In real app, this would validate with server
    const stored = localStorage.getItem('memory_monster_license');
    if (stored) {
      return JSON.parse(stored).status;
    }
    return 'free'; // Default to free
  }

  // Initialize scan count for free users
  initializeScanCount() {
    const scanData = localStorage.getItem('memory_monster_scans');
    if (!scanData) {
      // New user - give them 3 free scans
      const initialScans = {
        remaining: 3,
        used: 0,
        lastReset: new Date().toISOString()
      };
      localStorage.setItem('memory_monster_scans', JSON.stringify(initialScans));
    }
  }

  // Get remaining scans for free users
  getRemainingScans() {
    // Pro users have unlimited scans
    if (this.canAccessFeature('unlimited_scans')) {
      return 999; // Unlimited
    }

    const scanData = localStorage.getItem('memory_monster_scans');
    if (scanData) {
      const data = JSON.parse(scanData);
      return Math.max(0, data.remaining);
    }
    
    return 3; // Default for new users
  }

  // Use one scan (decrement count)
  decrementScans() {
    // Pro users don't lose scans
    if (this.canAccessFeature('unlimited_scans')) {
      return;
    }

    const scanData = localStorage.getItem('memory_monster_scans');
    if (scanData) {
      const data = JSON.parse(scanData);
      if (data.remaining > 0) {
        data.remaining -= 1;
        data.used += 1;
        localStorage.setItem('memory_monster_scans', JSON.stringify(data));
      }
    }
  }

  // Reset scans (for testing or daily reset)
  resetScans(count = 3) {
    const scanData = {
      remaining: count,
      used: 0,
      lastReset: new Date().toISOString()
    };
    localStorage.setItem('memory_monster_scans', JSON.stringify(scanData));
  }

  // The main function - checks if user can access a feature
  canAccessFeature(feature) {
    // Features that are always free
    const freeFeatures = [
      'basic_scan',           // Can scan system
      'manual_optimization',  // Can manually fix issues  
      'community_stats',      // Can see global stats
      'basic_app_support',    // Can optimize first 10 apps
      'dashboard_access',     // Can use main dashboard
      'settings_access'       // Can access settings
    ];

    // Features that require Pro
    const proFeatures = [
      'unlimited_scans',        // Unlimited scan count
      'multiple_optimizations', // Can optimize all issues at once
      'auto_optimization',      // Automatic memory fixing
      'real_time_monitoring',   // Background monitoring
      'advanced_scanning',      // Deep system scans
      'advanced_features',      // Advanced settings and features
      'all_app_support',       // All 250+ apps
      'background_optimization', // Fix issues automatically
      'detailed_analytics',     // Advanced performance metrics
      'priority_support',       // Customer support
      'custom_rules'           // Custom optimization rules
    ];

    // If it's a free feature, everyone gets it
    if (freeFeatures.includes(feature)) {
      return true;
    }

    // If it's a pro feature, check license
    if (proFeatures.includes(feature)) {
      return this.licenseStatus === 'pro' || this.licenseStatus === 'trial';
    }

    // If feature not found, deny access (safe default)
    return false;
  }

  // Get the list of apps user can optimize
  getAvailableApps() {
    const freeApps = [
      // Top 10 most popular apps for free tier
      'com.google.Chrome',        // Chrome
      'com.apple.Safari',         // Safari  
      'com.tinyspeck.slackmacgap', // Slack
      'com.spotify.client',       // Spotify
      'com.microsoft.teams',      // Teams
      'com.apple.mail',           // Mail
      'com.whatsapp.WhatsApp',    // WhatsApp
      'com.zoom.xos',             // Zoom
      'org.mozilla.firefox',      // Firefox
      'com.apple.Photos'          // Photos
    ];

    if (this.canAccessFeature('all_app_support')) {
      // Pro users get all apps (we'll add more later)
      return [...freeApps, 
        'com.adobe.Photoshop',
        'com.figma.Desktop',
        'com.sketch.3',
        // ... will add 240+ more apps
      ];
    }

    return freeApps;
  }

  // Check if user should see upgrade prompts for specific app
  shouldShowUpgradePrompt(appId) {
    const availableApps = this.getAvailableApps();
    return !availableApps.includes(appId) && 
           !this.canAccessFeature('all_app_support');
  }

  // Get upgrade message for specific feature
  getUpgradePrompt(feature) {
    const prompts = {
      'unlimited_scans': 'Upgrade to Pro for unlimited memory optimizations every day',
      'multiple_optimizations': 'Upgrade to Pro to fix all performance issues at once with one click',
      'auto_optimization': 'Upgrade to Pro to enable automatic memory optimization that runs in the background',
      'all_app_support': 'Unlock 240+ more apps including Adobe Creative Suite, development tools, and specialized software',
      'real_time_monitoring': 'Get real-time memory monitoring with instant alerts when your Mac needs attention',
      'advanced_scanning': 'Access deep system scanning that finds hidden memory leaks and performance bottlenecks',
      'advanced_features': 'Unlock advanced settings, custom rules, and professional optimization controls',
      'background_optimization': 'Let Memory Monster work silently in the background, keeping your Mac fast 24/7',
      'detailed_analytics': 'View detailed performance analytics and optimization history',
      'priority_support': 'Get priority email support and feature requests'
    };
    
    return prompts[feature] || 'Upgrade to Memory Monster Pro to unlock this premium feature';
  }

  // Simulate upgrading to pro (for testing)
  simulateProUpgrade() {
    localStorage.setItem('memory_monster_license', JSON.stringify({
      status: 'pro',
      purchaseDate: new Date().toISOString()
    }));
    this.licenseStatus = 'pro';
  }

  // Simulate starting trial (for testing)
  simulateTrialStart() {
    const trialEnd = new Date();
    trialEnd.setDate(trialEnd.getDate() + 7); // 7 days from now
    
    localStorage.setItem('memory_monster_license', JSON.stringify({
      status: 'trial',
      trialEnd: trialEnd.toISOString(),
      startDate: new Date().toISOString()
    }));
    this.licenseStatus = 'trial';
  }

  // Reset to free (for testing)
  simulateFreeReset() {
    localStorage.removeItem('memory_monster_license');
    this.licenseStatus = 'free';
    this.resetScans(3); // Reset to 3 free scans
  }

  // Get current license info for UI
  getLicenseInfo() {
    const stored = localStorage.getItem('memory_monster_license');
    const scanData = localStorage.getItem('memory_monster_scans');
    
    let scansRemaining = 3;
    if (scanData) {
      const data = JSON.parse(scanData);
      scansRemaining = Math.max(0, data.remaining);
    }

    if (stored) {
      const license = JSON.parse(stored);
      return {
        status: license.status,
        isPro: license.status === 'pro',
        isTrial: license.status === 'trial',
        isFree: license.status === 'free' || !license.status,
        isPaid: license.status === 'pro' || license.status === 'trial',
        tier: license.status === 'pro' ? 'Pro' : license.status === 'trial' ? 'Trial' : 'Free',
        trialEnd: license.trialEnd,
        purchaseDate: license.purchaseDate,
        scansRemaining: license.status === 'pro' || license.status === 'trial' ? 999 : scansRemaining
      };
    }
    
    return {
      status: 'free',
      isPro: false,
      isTrial: false, 
      isFree: true,
      isPaid: false,
      tier: 'Free',
      scansRemaining: scansRemaining
    };
  }
}

// Export for use in other files
export default FeatureGate;