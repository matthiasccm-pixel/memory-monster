/**
 * useFeatureGate.js - React Hook for easy feature access
 * This makes it super simple to check features in your components
 */

import { useState, useEffect, createContext, useContext } from 'react';
import FeatureGate from './FeatureGate.js';

// Create a context for the FeatureGate
const FeatureGateContext = createContext();

// Provider component - wrap your app with this
export const FeatureGateProvider = ({ children }) => {
  const [featureGate] = useState(() => new FeatureGate());
  const [licenseInfo, setLicenseInfo] = useState(featureGate.getLicenseInfo());

  // Listen for license changes
  useEffect(() => {
    const handleStorageChange = () => {
      setLicenseInfo(featureGate.getLicenseInfo());
    };

    // Listen for changes to localStorage (when license updates)
    window.addEventListener('storage', handleStorageChange);
    
    // Also check periodically in case license was updated programmatically
    const interval = setInterval(handleStorageChange, 1000); // Check every second for responsiveness

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, [featureGate]);

  return (
    <FeatureGateContext.Provider value={{ featureGate, licenseInfo, setLicenseInfo }}>
      {children}
    </FeatureGateContext.Provider>
  );
};

// Main hook - use this in your components
export const useFeatureGate = () => {
  const context = useContext(FeatureGateContext);
  
  if (!context) {
    throw new Error('useFeatureGate must be used within a FeatureGateProvider');
  }

  const { featureGate, licenseInfo, setLicenseInfo } = context;

  return {
    // NEW: Alias for canAccessFeature (matches scanning view expectations)
    hasFeature: (feature) => featureGate.canAccessFeature(feature),
    
    // NEW: Get remaining scans for free users
    getRemainingScans: () => featureGate.getRemainingScans(),
    
    // NEW: Decrement scan count
    decrementScans: () => {
      featureGate.decrementScans();
      setLicenseInfo(featureGate.getLicenseInfo()); // Update state immediately
    },
    
    // NEW: Open upgrade modal (placeholder for now)
    openUpgradeModal: () => {
      // For now, open external link - you can replace this with your modal logic
      window.open('https://memorymonster.co/join', '_blank');
    },
    
    // Check if user can access a feature (original method)
    canAccess: (feature) => featureGate.canAccessFeature(feature),
    
    // Get list of available apps
    getAvailableApps: () => featureGate.getAvailableApps(),
    
    // Check if should show upgrade prompt for app
    shouldShowUpgrade: (appId) => featureGate.shouldShowUpgradePrompt(appId),
    
    // Get upgrade message for feature
    getUpgradeMessage: (feature) => featureGate.getUpgradePrompt(feature),
    
    // License status info (both old and new format)
    license: licenseInfo,
    licenseInfo: licenseInfo, // NEW: matches scanning view expectations
    
    // Helper functions for common checks
    isPro: licenseInfo.isPro,
    isTrial: licenseInfo.isTrial,
    isFree: licenseInfo.isFree,
    
    // Functions to simulate license changes (for testing)
    simulateProUpgrade: () => {
      featureGate.simulateProUpgrade();
      setLicenseInfo(featureGate.getLicenseInfo());
    },
    
    simulateTrialStart: () => {
      featureGate.simulateTrialStart();
      setLicenseInfo(featureGate.getLicenseInfo());
    },
    
    simulateFreeReset: () => {
      featureGate.simulateFreeReset();
      setLicenseInfo(featureGate.getLicenseInfo());
    },
    
    // NEW: Reset scans (for testing)
    resetScans: (count = 3) => {
      featureGate.resetScans(count);
      setLicenseInfo(featureGate.getLicenseInfo());
    }
  };
};

export default useFeatureGate;