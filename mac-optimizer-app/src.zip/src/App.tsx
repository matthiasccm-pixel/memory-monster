import React from 'react';
import MacOptimizerApp from './MacOptimizerApp';

function App() {
  return <MacOptimizerApp />;
}

export default App;